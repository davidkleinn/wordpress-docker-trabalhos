<#
Executa o ambiente solicitado no Trabalho 1: WordPress + MySQL em Docker.
Abra o PowerShell nesta pasta e execute:
  powershell -ExecutionPolicy Bypass -File .\executar-trabalho-1.ps1
#>

param(
    [ValidateRange(1, 65535)]
    [int]$MySqlHostPort = 3307
)

$ErrorActionPreference = 'Stop'

if (-not (Get-Command docker -ErrorAction SilentlyContinue)) {
    $dockerDesktopCli = Join-Path $env:LOCALAPPDATA 'Programs\DockerDesktop\resources\bin\docker.exe'
    if (Test-Path -LiteralPath $dockerDesktopCli) {
        Set-Alias -Name docker -Value $dockerDesktopCli -Scope Local
    }
    else {
        throw 'Docker nao encontrado. Instale/inicie o Docker Desktop e execute este script novamente.'
    }
}

docker info | Out-Null
if ($LASTEXITCODE -ne 0) {
    throw 'O Docker Desktop foi encontrado, mas o mecanismo ainda nao esta em execucao. Abra-o e tente novamente.'
}

$existingNames = docker ps -a --format '{{.Names}}'
$conflicts = @('wordpress', 'wordpress-db') | Where-Object { $existingNames -contains $_ }
if ($conflicts) {
    throw "Ja existem conteineres com estes nomes: $($conflicts -join ', '). Renomeie-os ou remova-os conscientemente antes de continuar."
}

Write-Host 'Baixando a imagem do MySQL 5.7...'
docker pull mysql:5.7
if ($LASTEXITCODE -ne 0) { throw 'Falha ao baixar mysql:5.7.' }

Write-Host "Iniciando o MySQL (porta do host: $MySqlHostPort; porta interna: 3306)..."
docker run -d -p "${MySqlHostPort}:3306" --name wordpress-db `
    -e MYSQL_ROOT_PASSWORD=r00t `
    -e MYSQL_DATABASE=wordpress `
    -e MYSQL_USER=usr-wordpress `
    -e MYSQL_PASSWORD=pwd-wordpress `
    mysql:5.7
if ($LASTEXITCODE -ne 0) { throw 'Falha ao iniciar o conteiner wordpress-db.' }

Write-Host 'Aguardando a inicializacao inicial do MySQL...'
# O WordPress tentara a conexao novamente quando a pagina for aberta. A pausa evita
# interromper o script por causa do aviso emitido pelo mysqladmin no Windows PowerShell.
Start-Sleep -Seconds 20

Write-Host 'Iniciando o WordPress...'
docker run -d -p 8080:80 --name wordpress --link wordpress-db:mysql `
    -e WORDPRESS_DB_HOST=wordpress-db:3306 `
    -e WORDPRESS_DB_USER=usr-wordpress `
    -e WORDPRESS_DB_PASSWORD=pwd-wordpress `
    -e WORDPRESS_DB_NAME=wordpress `
    wordpress
if ($LASTEXITCODE -ne 0) { throw 'Falha ao iniciar o conteiner wordpress.' }

Write-Host ''
Write-Host 'Ambiente criado. Confira abaixo os dois conteineres:'
docker ps --filter 'name=wordpress' --format 'table {{.Names}}\t{{.Image}}\t{{.Status}}\t{{.Ports}}'
Write-Host ''
Write-Host 'Abra http://localhost:8080 para concluir o assistente de instalacao do WordPress.'
