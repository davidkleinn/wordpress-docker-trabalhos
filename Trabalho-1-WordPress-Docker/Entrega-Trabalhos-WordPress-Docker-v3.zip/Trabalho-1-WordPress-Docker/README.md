# Trabalho 1 - WordPress + MySQL com Docker

Esta entrega sobe os dois conteineres solicitados: `wordpress-db` (MySQL 5.7) e `wordpress` (WordPress), ligados pelo recurso `--link` mostrado no enunciado.

## Como executar

1. Abra o Docker Desktop e espere o status indicar que o mecanismo esta em execucao.
2. Abra um PowerShell nesta pasta.
3. Execute:

```powershell
powershell -ExecutionPolicy Bypass -File .\executar-trabalho-1.ps1
```

4. Acesse http://localhost:8080 e conclua o assistente de instalacao do WordPress.

O script nao remove conteineres ja existentes. Caso os nomes `wordpress` ou `wordpress-db` ja estejam em uso, ele para antes de fazer qualquer alteracao.

Se o Docker ainda nao estiver instalado, instale primeiro o WSL em um PowerShell aberto como administrador (`wsl --install`), reinicie quando o Windows solicitar e instale o Docker Desktop no modo WSL 2. A documentacao oficial do Docker descreve esse fluxo e os requisitos do Windows: https://docs.docker.com/desktop/setup/install/windows-install/

## O que o script configura

| Conteiner | Imagem | Porta do host | Configuracao |
|---|---|---:|---|
| `wordpress-db` | `mysql:5.7` | `3307` | Banco `wordpress`; usuario `usr-wordpress`; MySQL continua em `3306` dentro do conteiner |
| `wordpress` | `wordpress` | `8080` | Conectado ao banco pela porta `3306` |

As credenciais usadas sao as previstas no enunciado: senha root `r00t`, usuario `usr-wordpress` e senha `pwd-wordpress`. A porta externa foi definida como `3307` porque a porta `3306` desta maquina ja esta ocupada. Isso nao altera a comunicacao entre WordPress e MySQL: ela acontece internamente na porta `3306`. Em uma maquina onde a porta `3306` esteja livre, execute o script com `-MySqlHostPort 3306`.

## Comprovacao para a entrega

Depois de executar, registre uma captura do resultado destes comandos e da pagina de instalacao aberta no navegador:

```powershell
docker ps
docker images
```

O resultado esperado de `docker ps` deve mostrar `wordpress-db` com `0.0.0.0:3307->3306/tcp` e `wordpress` com `0.0.0.0:8080->80/tcp`.

## Encerramento (somente depois da avaliacao)

```powershell
docker stop wordpress wordpress-db
docker rm wordpress wordpress-db
```
