# Trabalho 2 - WordPress escalavel com Nginx e Docker Compose

Esta entrega cria exatamente cinco conteineres:

```text
Navegador -> nginx:80 -> wordpress1
                       -> wordpress2
                       -> wordpress3
                              |
                              +-> mysql:3306
```

O Nginx e o unico servico publicado para a maquina hospedeira. Os tres WordPress e o MySQL usam apenas redes internas do Compose, portanto nao possuem a secao `ports`.

## Arquivos da entrega

- `docker-compose.yml`: topologia com as imagens exigidas e cinco servicos.
- `nginx/nginx.conf`: pool upstream com os tres WordPress e cabecalho `X-Upstream` para demonstrar o balanceamento.
- `.env`: credenciais locais usadas pelo Compose.
- `wordpress/`: pasta da maquina hospedeira montada em `/var/www/html` nos tres WordPress e em `/usr/share/nginx/html` no Nginx.
- `validar.ps1`: valida, sobe os servicos e mostra o cabecalho de balanceamento varias vezes.

## Como executar

1. Abra o Docker Desktop e aguarde o mecanismo ficar em execucao.
2. Abra um PowerShell nesta pasta.
3. Execute:

```powershell
powershell -ExecutionPolicy Bypass -File .\validar.ps1
```

4. Abra http://localhost para terminar a instalacao inicial do WordPress. Como as tres instancias compartilham a mesma pasta e o mesmo banco, configure o site apenas uma vez.

Se esta maquina ainda nao tiver Docker, instale antes o WSL em um PowerShell aberto como administrador (`wsl --install`), reinicie se solicitado e instale o Docker Desktop usando o backend WSL 2. Consulte a documentacao oficial para os requisitos do Windows: https://docs.docker.com/desktop/setup/install/windows-install/

## Comprovacao para a entrega

Depois da inicializacao, execute novamente:

```powershell
docker compose ps
1..9 | ForEach-Object { curl.exe -sI http://localhost/ | Select-String '^X-Upstream:' }
```

O primeiro comando deve mostrar apenas os cinco conteineres. O segundo deve mostrar tres valores possiveis de `X-Upstream`, correspondentes aos IPs de `wordpress1`, `wordpress2` e `wordpress3` na rede `frontend`.

Tambem e possivel confirmar que WordPress e MySQL nao foram expostos ao host: em `docker compose ps`, somente `nginx` deve apresentar uma porta publicada (`0.0.0.0:80->80/tcp`).

## Encerramento (somente depois da avaliacao)

```powershell
docker compose down
```

O comando acima remove os conteineres e as redes; o volume nomeado do banco e preservado. Para descartar tambem os dados do banco, use `docker compose down -v` somente quando nao precisar mais deles.
