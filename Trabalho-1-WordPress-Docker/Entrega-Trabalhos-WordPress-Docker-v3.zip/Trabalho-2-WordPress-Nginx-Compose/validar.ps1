<#
Valida e inicia a topologia do Trabalho 2.
Execute no PowerShell, dentro desta pasta:
  powershell -ExecutionPolicy Bypass -File .\validar.ps1
#>

$ErrorActionPreference = 'Stop'

if (-not (Get-Command docker -ErrorAction SilentlyContinue)) {
    $dockerDesktopCli = Join-Path $env:LOCALAPPDATA 'Programs\DockerDesktop\resources\bin\docker.exe'
    if (Test-Path -LiteralPath $dockerDesktopCli) {
        Set-Alias -Name docker -Value $dockerDesktopCli -Scope Local
    }
    else {
        throw 'Docker nao encontrado. Instale/inicie o Docker Desktop e execute novamente.'
    }
}

docker info | Out-Null
if ($LASTEXITCODE -ne 0) {
    throw 'O Docker Desktop foi encontrado, mas o mecanismo ainda nao esta em execucao. Abra-o e tente novamente.'
}

Write-Host 'Validando a sintaxe do Compose...'
docker compose config | Out-Host
if ($LASTEXITCODE -ne 0) { throw 'A configuracao do Compose e invalida.' }

Write-Host 'Baixando imagens e iniciando os cinco conteineres...'
docker compose up -d
if ($LASTEXITCODE -ne 0) { throw 'Falha ao iniciar a topologia.' }

Write-Host 'Aguardando a inicializacao dos servicos...'
Start-Sleep -Seconds 20

Write-Host ''
Write-Host 'Estado esperado: nginx, wordpress1, wordpress2, wordpress3 e mysql em execucao.'
docker compose ps

Write-Host ''
Write-Host 'Teste de balanceamento - observe tres valores possiveis para X-Upstream:'
1..9 | ForEach-Object {
    curl.exe -sI http://localhost/ | Select-String -Pattern '^X-Upstream:'
    Start-Sleep -Seconds 1
}
