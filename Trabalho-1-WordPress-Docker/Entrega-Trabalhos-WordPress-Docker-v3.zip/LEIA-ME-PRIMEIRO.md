# Entrega - Trabalhos de WordPress com Docker

O arquivo ZIP desta pasta contem duas entregas independentes, prontas para serem descompactadas e executadas em uma maquina com Docker Desktop:

1. **Trabalho 1 - WordPress + MySQL com Docker**: execute `executar-trabalho-1.ps1` e acesse `http://localhost:8080`.
2. **Trabalho 2 - tres WordPress com Nginx e Docker Compose**: execute `validar.ps1` e acesse `http://localhost`.

Cada diretorio inclui um README com os requisitos, os comandos de execucao e o que deve aparecer na validacao.

## Antes de apresentar ou enviar

1. Com o Docker Desktop aberto, execute cada script na respectiva pasta.
2. Faça uma captura de tela da saida de `docker ps` (Trabalho 1) e de `docker compose ps` mais os cabecalhos `X-Upstream` (Trabalho 2).
3. Faça uma captura da pagina de instalacao do WordPress em `localhost:8080` e `localhost`, respectivamente.
4. Envie o ZIP e, se a plataforma permitir, as capturas. Nao use os comandos de encerramento antes de concluir as capturas.

## Nota de ambiente

No momento da montagem desta entrega, esta maquina nao possuia Docker/WSL disponivel para iniciar os conteineres. Por isso, os arquivos foram revisados estaticamente (PowerShell e estrutura dos servicos), mas as capturas reais devem ser geradas apos o Docker Desktop estar rodando. Isso evita apresentar resultados que nao foram executados.
